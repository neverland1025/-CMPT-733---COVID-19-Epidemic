# Government Policy Model
```sh
$ jupyter-notebook
```