# Notebooks for EDA
```shell
$ jupyter-notebook
```