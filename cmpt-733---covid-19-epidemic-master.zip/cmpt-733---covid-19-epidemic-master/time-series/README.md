# Time Series Models
```shell
$ jupyter-notebook
```